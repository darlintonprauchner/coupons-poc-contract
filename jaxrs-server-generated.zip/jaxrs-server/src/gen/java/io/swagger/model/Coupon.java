package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;





@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-05-23T08:12:59.090Z")
public class Coupon   {
  
  private String code = null;
  private String name = null;
  private String description = null;
  private Integer numMaxUsage = null;
  private String expirationDate = null;
  private Integer discount = null;

  
  /**
   **/
  public Coupon code(String code) {
    this.code = code;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("code")
  public String getCode() {
    return code;
  }
  public void setCode(String code) {
    this.code = code;
  }

  
  /**
   **/
  public Coupon name(String name) {
    this.name = name;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  
  /**
   **/
  public Coupon description(String description) {
    this.description = description;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  
  /**
   **/
  public Coupon numMaxUsage(Integer numMaxUsage) {
    this.numMaxUsage = numMaxUsage;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("numMaxUsage")
  public Integer getNumMaxUsage() {
    return numMaxUsage;
  }
  public void setNumMaxUsage(Integer numMaxUsage) {
    this.numMaxUsage = numMaxUsage;
  }

  
  /**
   **/
  public Coupon expirationDate(String expirationDate) {
    this.expirationDate = expirationDate;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("expirationDate")
  public String getExpirationDate() {
    return expirationDate;
  }
  public void setExpirationDate(String expirationDate) {
    this.expirationDate = expirationDate;
  }

  
  /**
   **/
  public Coupon discount(Integer discount) {
    this.discount = discount;
    return this;
  }

  
  @ApiModelProperty(value = "")
  @JsonProperty("discount")
  public Integer getDiscount() {
    return discount;
  }
  public void setDiscount(Integer discount) {
    this.discount = discount;
  }

  

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Coupon coupon = (Coupon) o;
    return Objects.equals(code, coupon.code) &&
        Objects.equals(name, coupon.name) &&
        Objects.equals(description, coupon.description) &&
        Objects.equals(numMaxUsage, coupon.numMaxUsage) &&
        Objects.equals(expirationDate, coupon.expirationDate) &&
        Objects.equals(discount, coupon.discount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, name, description, numMaxUsage, expirationDate, discount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Coupon {\n");
    
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    numMaxUsage: ").append(toIndentedString(numMaxUsage)).append("\n");
    sb.append("    expirationDate: ").append(toIndentedString(expirationDate)).append("\n");
    sb.append("    discount: ").append(toIndentedString(discount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

