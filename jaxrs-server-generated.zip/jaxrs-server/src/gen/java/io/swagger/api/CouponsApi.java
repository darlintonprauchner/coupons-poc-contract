package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.CouponsApiService;
import io.swagger.api.factories.CouponsApiServiceFactory;

import io.swagger.annotations.ApiParam;

import com.sun.jersey.multipart.FormDataParam;

import io.swagger.model.Coupon;
import io.swagger.model.ValidationResult;

import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;

@Path("/coupons")


@io.swagger.annotations.Api(description = "the coupons API")
@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-05-23T08:12:59.090Z")
public class CouponsApi  {
   private final CouponsApiService delegate = CouponsApiServiceFactory.getCouponsApi();

    @POST
    
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Add a new coupon", notes = "", response = void.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "coupons_auth", scopes = {
            @io.swagger.annotations.AuthorizationScope(scope = "write_coupons", description = "modify coupons"),
            @io.swagger.annotations.AuthorizationScope(scope = "read_coupons", description = "read coupons")
        })
    }, tags={ "coupon",  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 405, message = "Invalid input", response = void.class) })
    public Response addCoupon(
        @ApiParam(value = "Coupon object that needs to be added" ) Coupon body,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.addCoupon(body,securityContext);
    }
    @DELETE
    @Path("/{code}")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Deletes a coupon", notes = "", response = void.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "coupons_auth", scopes = {
            @io.swagger.annotations.AuthorizationScope(scope = "write_coupons", description = "modify coupons"),
            @io.swagger.annotations.AuthorizationScope(scope = "read_coupons", description = "read coupons")
        })
    }, tags={ "coupon",  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 400, message = "Invalid coupon code value", response = void.class) })
    public Response deleteCoupon(
        @ApiParam(value = "" ,required=true)@HeaderParam("api_key") String apiKey,
        @ApiParam(value = "Code to delete",required=true) @PathParam("code") String code,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.deleteCoupon(apiKey,code,securityContext);
    }
    @GET
    
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Finds coupons", notes = "Returns all coupons.", response = Coupon.class, responseContainer = "List", authorizations = {
        @io.swagger.annotations.Authorization(value = "coupons_auth", scopes = {
            @io.swagger.annotations.AuthorizationScope(scope = "write_coupons", description = "modify coupons"),
            @io.swagger.annotations.AuthorizationScope(scope = "read_coupons", description = "read coupons")
        })
    }, tags={ "coupon",  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "successful operation", response = Coupon.class, responseContainer = "List") })
    public Response getAllCoupons(
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getAllCoupons(securityContext);
    }
    @GET
    @Path("/{code}")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Find coupon by code", notes = "Returns a coupon with CODE = code", response = Coupon.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "api_key"),
        @io.swagger.annotations.Authorization(value = "coupons_auth", scopes = {
            @io.swagger.annotations.AuthorizationScope(scope = "write_coupons", description = "modify coupons"),
            @io.swagger.annotations.AuthorizationScope(scope = "read_coupons", description = "read coupons")
        })
    }, tags={ "coupon",  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "successful operation", response = Coupon.class),
        @io.swagger.annotations.ApiResponse(code = 400, message = "Invalid coupon supplied", response = Coupon.class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "Coupon not found", response = Coupon.class) })
    public Response getCouponByCode(
        @ApiParam(value = "Code of coupon that needs to be fetched",required=true) @PathParam("code") String code,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.getCouponByCode(code,securityContext);
    }
    @POST
    @Path("/{code}/redemptions")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Attempt to redeem a coupon.", notes = "This consumes one use of the coupon.", response = void.class, tags={ "coupon", "redemption",  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 201, message = "The coupon is valid and grants a discount", response = void.class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "Coupon not found", response = void.class) })
    public Response redeemCoupon(
        @ApiParam(value = "the coupon code",required=true) @PathParam("code") String code,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.redeemCoupon(code,securityContext);
    }
    @PUT
    
    @Consumes({ "application/json" })
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Update an existing coupon", notes = "", response = void.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "coupons_auth", scopes = {
            @io.swagger.annotations.AuthorizationScope(scope = "write_coupons", description = "modify coupons"),
            @io.swagger.annotations.AuthorizationScope(scope = "read_coupons", description = "read coupons")
        })
    }, tags={ "coupon",  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 400, message = "Invalid CODE supplied", response = void.class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "Coupon not found", response = void.class),
        @io.swagger.annotations.ApiResponse(code = 405, message = "Validation exception", response = void.class) })
    public Response updateCoupon(
        @ApiParam(value = "Coupon object that needs to be added" ) Coupon body,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.updateCoupon(body,securityContext);
    }
    @POST
    @Path("/{code}/validations")
    
    @Produces({ "application/json" })
    @io.swagger.annotations.ApiOperation(value = "Attempt to validate a coupon and get the discount that it grants.", notes = "This does not consume the coupon.", response = ValidationResult.class, tags={ "coupon", "validation" })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 201, message = "The coupon is valid and grants a discount", response = ValidationResult.class),
        @io.swagger.annotations.ApiResponse(code = 204, message = "The coupon exists, but does not grant a discount", response = ValidationResult.class),
        @io.swagger.annotations.ApiResponse(code = 404, message = "Coupon not found", response = ValidationResult.class) })
    public Response validateCoupon(
        @ApiParam(value = "the coupon code",required=true) @PathParam("code") String code,
        @Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.validateCoupon(code,securityContext);
    }
}
