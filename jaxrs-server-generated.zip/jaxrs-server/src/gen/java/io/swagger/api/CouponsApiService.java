package io.swagger.api;

import io.swagger.api.*;
import io.swagger.model.*;

import com.sun.jersey.multipart.FormDataParam;

import io.swagger.model.Coupon;
import io.swagger.model.ValidationResult;

import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-05-23T08:12:59.090Z")
public abstract class CouponsApiService {
  
      public abstract Response addCoupon(Coupon body,SecurityContext securityContext)
      throws NotFoundException;
  
      public abstract Response deleteCoupon(String apiKey,String code,SecurityContext securityContext)
      throws NotFoundException;
  
      public abstract Response getAllCoupons(SecurityContext securityContext)
      throws NotFoundException;
  
      public abstract Response getCouponByCode(String code,SecurityContext securityContext)
      throws NotFoundException;
  
      public abstract Response redeemCoupon(String code,SecurityContext securityContext)
      throws NotFoundException;
  
      public abstract Response updateCoupon(Coupon body,SecurityContext securityContext)
      throws NotFoundException;
  
      public abstract Response validateCoupon(String code,SecurityContext securityContext)
      throws NotFoundException;
  
}
