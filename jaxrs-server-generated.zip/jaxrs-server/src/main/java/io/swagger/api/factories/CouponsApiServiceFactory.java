package io.swagger.api.factories;

import io.swagger.api.CouponsApiService;
import io.swagger.api.impl.CouponsApiServiceImpl;

@javax.annotation.Generated(value = "class io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2016-05-23T08:12:59.090Z")
public class CouponsApiServiceFactory {

   private final static CouponsApiService service = new CouponsApiServiceImpl();

   public static CouponsApiService getCouponsApi()
   {
      return service;
   }
}
